Security Policy

Please report security issues using the following form:
https://github.com/cp-57/supply-chain-security/security/advisories/new


Report Responses:
A maintainer will reach out to you regarding your report as soon as possible. 
